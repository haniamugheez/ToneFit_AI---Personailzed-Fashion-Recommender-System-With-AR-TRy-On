from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
import os
from Authentication.database import get_db
from Authentication.auth import get_current_user
from Authentication import models

router = APIRouter(prefix="/tryon", tags=["TryOn"])

@router.post("/capture")
async def save_tryon_image(
    product_id: int,
    image_file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    # 1. Image ko static folder mein save karein (like static/tryon_data)
    file_path = f"static/tryon_data/{current_user.id}_{datetime.now().timestamp()}.jpg"
    with open(file_path, "wb") as f:
        f.write(image_file.file.read())
        
    # 2. Database mein entry create karein
    new_tryon = models.TryOnHistory(
        user_id=current_user.id,
        product_id=product_id,
        tryon_image_url=file_path
    )
    db.add(new_tryon)
    db.commit()
    db.refresh(new_tryon)
    
    return {"message": "Image captured and saved to history successfully!", "data": new_tryon}