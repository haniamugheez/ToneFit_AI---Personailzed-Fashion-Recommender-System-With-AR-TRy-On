# from fastapi import APIRouter, Depends, HTTPException
# from sqlalchemy.orm import Session
# from Authentication.database import get_db
# from Authentication.auth import get_current_user
# from Authentication import models
# from pydantic import BaseModel

# router = APIRouter(prefix="/payment", tags=["Payment & Checkout"])

# class CheckoutDetails(BaseModel):
#     delivery_address: str
#     payment_method: str

# @router.post("/checkout")
# async def process_checkout(details: CheckoutDetails, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
#     # 1. Fetch user's cart items
#     cart_items = db.query(models.Cart).filter(models.Cart.user_id == current_user.id).all()
#     if not cart_items:
#         raise HTTPException(status_code=400, detail="Your cart is empty.")

#     # 2. Loop through items to check stock levels
#     for item in cart_items:
#         variant = db.query(models.ProductVariant).filter(
#             models.ProductVariant.product_id == item.product_id,
#             models.ProductVariant.size == item.size
#         ).first()
        
#         if not variant or variant.stock < item.quantity:
#             raise HTTPException(status_code=400, detail=f"Product ID {item.product_id} does not have the required size in stock.")
        
#         # 🔥 UPDATE STOCK (Deduct from Database)
#         variant.stock -= item.quantity

#     # 3. Clear the cart since the order is confirmed
#     db.query(models.Cart).filter(models.Cart.user_id == current_user.id).delete()
    
#     # 4. Save changes to DB
#     db.commit()

#     return {
#         "status": "Order Placed Successfully",
#         "message": f"Your order via {details.payment_method} has been confirmed and will be delivered shortly!",
#         "delivery_to": details.delivery_address
#     }


from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from Authentication.database import get_db
from Authentication.auth import get_current_user
from Authentication import models
from pydantic import BaseModel
from datetime import datetime

router = APIRouter(prefix="/payment", tags=["Payment & Checkout"])

# =====================================================================
# PYDANTIC SCHEMAS (Data Validation ke liye)
# =====================================================================

class CheckoutDetails(BaseModel):
    delivery_address: str
    payment_method: str                 # "Debit/Credit Card" ya "COD"
    card_number: Optional[str] = None   # Optional taake COD par error na aaye
    expiry_date: Optional[str] = None   # Optional (e.g., "12/28")
    cvv: Optional[str] = None           # Optional (e.g., "123")

class AddressCreate(BaseModel):
    full_name: str
    phone_number: str
    province: str
    city: str
    area_code: Optional[str] = None
    complete_address: str
    label: str = "Home"

class ReviewCreate(BaseModel):
    brand_name: str
    rating: int
    comment: Optional[str] = None


# =====================================================================
# 1. PROCESS CHECKOUT (With Automatic Notification Logic 🔥)
# =====================================================================
@router.post("/checkout")
async def process_checkout(details: CheckoutDetails, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # i. Logged-in user ki cart se saari items nikalhein
    cart_items = db.query(models.Cart).filter(models.Cart.user_id == current_user.id).all()
    if not cart_items:
        raise HTTPException(status_code=400, detail="Checkout failed. Your cart is empty.")

    # ii. Validation Check: Agar card payment select ki hai to details lazmi hon
    if details.payment_method == "Debit/Credit Card":
        if not details.card_number or not details.expiry_date or not details.cvv:
            raise HTTPException(
                status_code=400, 
                detail="Debit/Credit Card details fill karna lazmi hain."
            )

    # iii. Main Order generate karein (Address aur Payment Method save karne ke liye)
    new_order = models.Order(
        user_id=current_user.id,
        delivery_address=details.delivery_address,
        payment_method=details.payment_method,
        status="Pending"
    )
    db.add(new_order)
    db.flush()  # Isse new_order.id instantly generate ho jayegi loop ke liye

    # iv. Cart items par loop chala kar direct product details map karein
    for item in cart_items:
        product_details = db.query(models.Product).filter(models.Product.id == item.product_id).first()
        
        if not product_details:
            db.rollback()
            raise HTTPException(
                status_code=404, 
                detail=f"Product ID {item.product_id} not found in our catalog."
            )

        # OrderItems history table mein data insert karein
        order_item = models.OrderItems(
            order_id=new_order.id,
            product_id=item.product_id,
            size=item.size,  
            quantity=item.quantity,
            price=product_details.price,
            main_category=product_details.main_category,
            sub_category=product_details.sub_category,
            brand_name=product_details.brand_name
        )
        db.add(order_item)

        # 🔥 AUTOMATIC NOTIFICATION GENERATION LOGIC:
        # Check karte hain ke kya ye product recommended hai (agar is_recommended ya similar field model me ho)
        # Warna safe side ke liye dynamic text generate hoga jo brand aur details bataaye ga
        is_rec = getattr(product_details, 'is_recommended', False)
        
        if is_rec:
            notif_msg = f"Aap ke recommended items mein se {product_details.brand_name} ka product buy ho gaya hai!"
            notif_title = "Recommended Product Purchased ✨"
        else:
            notif_msg = f"Brand {product_details.brand_name} ka product successfully buy ho gaya hai!"
            notif_title = "Brand Product Purchased 🛍️"

        # Notification table mein store karna
        new_notification = models.Notification(
            user_id=current_user.id,
            title=notif_title,
            message=notif_msg,
            is_read=False
        )
        db.add(new_notification)

    # v. Successful transaction ke baad active user ki cart khali kar dein
    db.query(models.Cart).filter(models.Cart.user_id == current_user.id).delete()
    
    # vi. Saara data database mein permanently commit (save) karein
    db.commit()

    return {
        "status": "Order Placed Successfully",
        "order_id": new_order.id,
        "message": f"Your order via {details.payment_method} has been confirmed and will be processed shortly!",
        "delivery_to": details.delivery_address
    }


# =====================================================================
# 2. NOTIFICATION MANAGEMENT ENDPOINTS (New Added)
# =====================================================================

# i. GET ALL NOTIFICATIONS (List laane ke liye)
@router.get("/notifications")
async def get_user_notifications(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # Saari notifications latest first (descending order) load hongi
    notifications = db.query(models.Notification).filter(
        models.Notification.user_id == current_user.id
    ).order_by(models.Notification.created_at.desc()).all()
    
    return notifications


# ii. MARK ALL AS READ (Sari notifications ko ek sath read karne ka button)
@router.put("/notifications/read-all")
async def mark_all_notifications_as_read(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # Unread notifications ko filter karke unka status true (Read) kar dena
    db.query(models.Notification).filter(
        models.Notification.user_id == current_user.id,
        models.Notification.is_read == False
    ).update({"is_read": True}, synchronize_session=False)
    
    db.commit()
    return {"status": "Success", "message": "Saari notifications read mark ho chuki hain."}


# =====================================================================
# 3. ADDRESS MANAGEMENT ENDPOINTS
# =====================================================================
@router.post("/address")
async def add_delivery_address(address_data: AddressCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    new_address = models.UserAddress(user_id=current_user.id, **address_data.dict())
    db.add(new_address)
    db.commit()
    db.refresh(new_address)
    return {"status": "Address Saved", "address": new_address}

@router.get("/addresses")
async def get_saved_addresses(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    addresses = db.query(models.UserAddress).filter(models.UserAddress.user_id == current_user.id).all()
    return addresses


# =====================================================================
# 4. ORDER HISTORY (Pending / Delivered List tabs ke liye)
# =====================================================================
@router.get("/my-orders")
async def get_my_orders(status: str, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    orders = db.query(models.Order).filter(
        models.Order.user_id == current_user.id,
        models.Order.status == status
    ).all()
    
    result = []
    for order in orders:
        items = db.query(models.OrderItems).filter(models.OrderItems.order_id == order.id).all()
        result.append({
            "order_id": order.id,
            "delivery_address": order.delivery_address,
            "payment_method": order.payment_method,
            "status": order.status,
            "created_at": order.created_at,
            "items": items
        })
    return result


# =====================================================================
# 5. UPDATE ORDER STATUS (Testing ke liye tool)
# =====================================================================
@router.put("/{order_id}/status")
async def update_order_status(order_id: int, new_status: str, db: Session = Depends(get_db)):
    order = db.query(models.Order).filter(models.Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found.")
    
    order.status = new_status
    db.commit()
    return {"message": f"Order status successfully changed to {new_status}."}


# =====================================================================
# 6. POST ORDER REVIEW (Order deliver honay ke baad review allow karega)
# =====================================================================
@router.post("/submit-review")
async def submit_brand_review(review: ReviewCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    has_delivered_order = db.query(models.OrderItems).join(models.Order).filter(
        models.Order.user_id == current_user.id,
        models.Order.status == "Delivered",
        models.OrderItems.brand_name == review.brand_name
    ).first()
    
    if not has_delivered_order:
        raise HTTPException(
            status_code=400, 
            detail="Aap review sirf tabhi de sakty hain jab aapka order successfully Delivered ho chuka ho."
        )

    new_review = models.BrandReview(
        user_id=current_user.id,
        brand_name=review.brand_name,
        rating=review.rating,
        comment=review.comment
    )
    db.add(new_review)
    db.commit()
    
    return {"status": "Review Submitted", "message": f"Thank you for reviewing {review.brand_name}!"}