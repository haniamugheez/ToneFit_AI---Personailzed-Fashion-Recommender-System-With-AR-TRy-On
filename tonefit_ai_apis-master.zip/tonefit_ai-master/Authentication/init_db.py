from Authentication.database import Base, engine
from Authentication.models import User

print("Creating database tables...")
Base.metadata.create_all(bind=engine)
print("Done.")