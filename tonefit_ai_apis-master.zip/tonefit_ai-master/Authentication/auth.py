# from passlib.context import CryptContext
# from datetime import datetime, timedelta
# from jose import jwt
# import hashlib

# SECRET_KEY = "change_this_to_a_random_secret_in_prod"
# ALGORITHM = "HS256"
# ACCESS_TOKEN_EXPIRE_MINUTES = 30

# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# def _prehash(password: str) -> str:
#     return hashlib.sha256(password.encode("utf-8")).hexdigest()

# def hash_password(password: str) -> str:
#     return pwd_context.hash(_prehash(password))

# def verify_password(password: str, hashed: str) -> bool:
#     return pwd_context.verify(_prehash(password), hashed)

# def create_access_token(data: dict, expires_minutes: int = ACCESS_TOKEN_EXPIRE_MINUTES) -> str:
#     to_encode = data.copy()
#     expire = datetime.utcnow() + timedelta(minutes=expires_minutes)
#     to_encode.update({"exp": expire})
#     return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

from passlib.context import CryptContext
from datetime import datetime, timedelta
from jose import jwt, JWTError
import hashlib
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
import Authentication.database as database, Authentication.models as models # Ensure these exist

SECRET_KEY = "change_this_to_a_random_secret_in_prod"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

def _prehash(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def validate_password(password: str) -> bool:
    """Password ko validate karo pehle hash karne se"""
    if not password:
        raise ValueError("Password cannot be emptys")
    
    if len(password) < 8:
        raise ValueError("Password should be at least 8 characters long")
    
    # SHA256 hexdigest 64 bytes hota hai jo bcrypt ke limit se safe hai
    # Lekin extra safety check karo
    if len(password) > 100:
        raise ValueError("Password is too long. Please choose a shorter password.")
    
    return True

# Phir hash_password() ko yeh se replace karo:
def hash_password(password: str) -> str:
    validate_password(password)  # Yeh line ADD KARO
    return pwd_context.hash(_prehash(password))

def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(_prehash(password), hashed)

def create_access_token(data: dict, expires_minutes: int = ACCESS_TOKEN_EXPIRE_MINUTES) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=expires_minutes)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# Is function ko verify karein ke email crud se kaise aa raha hai
def get_current_user(db: Session = Depends(database.get_db), token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    
    # Direct model query (Circular import se bachne ke liye crud ki jagah yahan direct use karein)
    user = db.query(models.User).filter(models.User.email == email).first()
    if user is None:
        raise credentials_exception
    return user


# Phir authenticate_user() ko yeh se replace karo:
def authenticate_user(db: Session, email: str, password: str):
    user = db.query(models.User).filter(
        models.User.email == email, 
        models.User.is_deleted == False  # Yeh line ADD KARO
    ).first()
    if not user:
        return False
    if not verify_password(password, user.password):
        return False
    return user