# from pydantic import BaseModel, EmailStr , validator

# class UserRegister(BaseModel):
#     first_name: str
#     last_name: str
#     phone_number: str
#     email: EmailStr
#     password: str
#     confirm_password: str

#     @validator('confirm_password')
#     def passwords_match(cls, v, values):
#         if 'password' in values and v != values['password']:
#             raise ValueError('Passwords do not match!')
#         return v

# class UserLogin(BaseModel):
#     email: EmailStr
#     password: str

# class UserOut(BaseModel): 
#     id: int
#     first_name: str
#     last_name: str
#     phone_number: str
#     email: EmailStr
#     class Config:
#         from_attributes = True

# class Token(BaseModel):
#     access_token: str
#     token_type: str

# ----------------- FINAL SCHEMAS LOGIC -----------------

from pydantic import BaseModel, EmailStr, validator
from typing import Optional
from datetime import datetime

# 1. Registration Model (Includes password matching validation)
class UserRegister(BaseModel):
    first_name: str
    last_name: str
    phone_number: str
    email: EmailStr
    password: str
    confirm_password: str

    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'password' in values and v != values['password']:
            raise ValueError('Passwords do not match!')
        return v

# 2. Login Model
class UserLogin(BaseModel):
    email: EmailStr
    password: str

# 3. User Output Model (Profile aur API response ke liye)
class UserOut(BaseModel): 
    id: int
    first_name: str
    last_name: str
    phone_number: str
    email: EmailStr
    is_active: bool
    is_deleted: bool  # Soft delete status check karne ke liye
    profile_image: Optional[str] = None 
    
    class Config:
        from_attributes = True

# 4. Token Model (Authentication ke liye)
class Token(BaseModel):
    access_token: str
    token_type: str

# 5. OTP Verification Model (Registration ke baad active karne ke liye)
class VerifyOTP(BaseModel):
    phone_number: str
    otp_code: str

# 6. Change Password Model (Jab user Login ho aur purana password badalna chahay)
class PasswordReset(BaseModel):
    new_password: str
    confirm_password: str

    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match!')
        return v

# 7. Forget Password Request (Step 1: Sirf email mangne ke liye)
class ForgotPassword(BaseModel):
    email: EmailStr

# 8. Reset Password Confirm (Step 2: OTP aur Naya Password verify karne ke liye)
class ResetPassword(BaseModel):
    email: EmailStr
    otp_code: str
    new_password: str
    confirm_password: str

    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('Passwords do not match!')
        return v
    

class DeleteAccount(BaseModel):
    password: str  # Confirmation ke liye

# Resend OTP Model
class ResendOTP(BaseModel):
    phone_number: str

# OTP Timer Response
class OTPStatus(BaseModel):
    can_resend: bool
    seconds_until_resend: int  # Kitne seconds baad resend kar sakta hai
    message: str

class SkinToneResponse(BaseModel):
    id: int
    detected_tone: str
    hex_code: str
    
    class Config:
        #orm_mode = True
       from_attributes = True


# --- Brand Schemas ---
class BrandResponse(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    is_favorite: bool = False

    class Config:
        from_attributes = True

# --- Address Schemas ---
class AddressCreate(BaseModel):
    full_name: str
    phone_number: str
    province: str
    city: str
    area_code: Optional[str] = None
    complete_address: str
    label: str = "Home"

class AddressResponse(AddressCreate):
    id: int
    user_id: int
    class Config: from_attributes = True

# --- Checkout & Order Schemas ---
class CheckoutRequest(BaseModel):
    delivery_address: str
    payment_method: str

class OrderItemResponse(BaseModel):
    id: int
    product_id: int
    quantity: int
    size: str
    brand_name: str
    price: float
    class Config: from_attributes = True

class OrderResponse(BaseModel):
    id: int
    delivery_address: str
    payment_method: str
    status: str
    created_at: datetime
    items: List[OrderItemResponse]
    class Config: from_attributes = True

# --- Review Schema ---
class ReviewCreate(BaseModel):
    brand_name: str
    rating: int
    comment: Optional[str] = None