from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

# Line 6: Yahan RDS ka endpoint daalein (copy-paste karke)
DB_HOST = os.getenv("DB_HOST", "tonefitairds.c7qw2gcygsnz.eu-north-1.rds.amazonaws.com")

# Line 9: Yahan username bhi update karein (agar 'root' nahi hai to)
# Aksar RDS ka default username 'admin' hota hai, 'root' nahi.
DATABASE_URL = f"mysql+pymysql://mysqladmin:{'123$hania'}@{DB_HOST}:3306/AWS_ToneFit_Db"



# Yahan par update karein:
engine = create_engine(
    DATABASE_URL, 
    echo=False,
    pool_pre_ping=True,          # Har query se pehle check karega ke connection zinda hai
    pool_recycle=3600,           # Connection ko har 1 ghante baad recycle karega
    connect_args={"connect_timeout": 60} # Database reply ke liye 60 seconds ka waqt dega
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
