# from sqlalchemy import Column, Integer, String
# from database import Base

# class User(Base):
#     __tablename__ = "users"
#     id = Column(Integer, primary_key=True, index=True)
#     #username = Column(String(50), unique=True, index=True, nullable=False)
#     first_name = Column(String(50), nullable=True)
#     last_name = Column(String(50), nullable=True)
#     #phone_number = Column(String(15),+92, nullable=True)
#     phone_number = Column(String(15), nullable=True)
#     email = Column(String(100), unique=True, index=True, nullable=False)
#     password = Column(String(255), nullable=False)

# ----------------- FINAL MODELS LOGIC -----------------

from datetime import datetime
from typing import Optional
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Float
from sqlalchemy.orm import relationship
from Authentication.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    first_name = Column(String(50), nullable=True)
    last_name = Column(String(50), nullable=True)
    phone_number = Column(String(15), nullable=True)
    email = Column(String(100), unique=True, index=True, nullable=False)
    password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=False) 
    profile_image = Column(String(255), nullable=True)
    is_deleted = Column(Boolean, default=False) 
    otp_code = Column(String(6), nullable=True)  # OTP store karne ke liye
    otp_expires_at = Column(DateTime, nullable=True)  # OTP expiry time
    last_otp_sent_at = Column(DateTime, nullable=True)  # Resend limit ke liye

    skin_analyses = relationship("SkinToneAnalysis", back_populates="owner")


class SkinToneAnalysis(Base):
    __tablename__ = "skin_tone_analysis"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    detected_tone = Column(String(50))
    hex_code = Column(String(10))
    skin_image_path = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)

    owner = relationship("User", back_populates="skin_analyses")


class Product(Base):
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100))
    image_url = Column(String(255))
    sub_category = Column(String(100), nullable=True)
    main_category = Column(String(100), nullable=True) # maps to your main_category column in workbench
    brand_name = Column(String(100), nullable=True)
    price = Column(String(100), nullable=False, default="0")




class Cart(Base):
    __tablename__ = "cart"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"))
    size = Column(String(10), nullable=False)
    quantity = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")
    product = relationship("Product")


class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    delivery_address = Column(String(255), nullable=False)
    payment_method = Column(String(50), nullable=False)
    status = Column(String(50), default="Pending")
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")
    # 🔥 ERROR FIX: 'items' relationship yahan define hona lazmi tha!
    items = relationship("OrderItems", back_populates="order", cascade="all, delete-orphan")


class OrderItems(Base):
    __tablename__ = "order_items"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id", ondelete="CASCADE"))
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"))
    quantity = Column(Integer, nullable=False, default=1)
    size = Column(String(10), nullable=False)
    # Snapshot columns at the time of purchase
    main_category = Column(String(100), nullable=True)
    sub_category = Column(String(100), nullable=True)
    brand_name = Column(String(100), nullable=True)
    price = Column(Float, nullable=False)
    

    order = relationship("Order", back_populates="items")
    product = relationship("Product")

from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, Boolean, Float
from sqlalchemy.orm import relationship
from datetime import datetime

# ---- BAAQI PURANE TABLES WAISE HI RAHENGE ----

class Brand(Base):
    __tablename__ = "brands"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True) 
    description = Column(String(255), nullable=True)    
    image_url = Column(String(255), nullable=True)      


class FavoriteBrand(Base):
    __tablename__ = "favorite_brands"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    brand_id = Column(Integer, ForeignKey("brands.id", ondelete="CASCADE"))

    brand = relationship("Brand")


class UserAddress(Base):
    __tablename__ = "user_addresses"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    full_name = Column(String(100), nullable=False)
    phone_number = Column(String(20), nullable=False)
    province = Column(String(100), nullable=False)
    city = Column(String(100), nullable=False)
    area_code = Column(String(20), nullable=True)
    complete_address = Column(String(255), nullable=False)
    label = Column(String(20), default="Home") 
    is_default = Column(Boolean, default=False)


class BrandReview(Base):
    __tablename__ = "brand_reviews"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    brand_name = Column(String(100), nullable=False) 
    rating = Column(Integer, nullable=False)         
    comment = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")

class CheckoutDetails(BaseModel):
    delivery_address: str
    payment_method: str             # "Debit/Credit Card" ya "COD"
    card_number: Optional[str] = None   # Optional taake COD par error na aaye
    expiry_date: Optional[str] = None   # Optional (e.g., "12/28")
    cvv: Optional[str] = None           # Optional (e.g., "123")

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    title = Column(String(100), nullable=False)
    message = Column(String(255), nullable=False)
    is_read = Column(Boolean, default=False) # Shuru mein unread hoga
    created_at = Column(DateTime, default=datetime.utcnow)

class TryOnHistory(Base):
    __tablename__ = "tryon_history"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    product_id = Column(Integer, ForeignKey("products.id"))
    tryon_image_url = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)