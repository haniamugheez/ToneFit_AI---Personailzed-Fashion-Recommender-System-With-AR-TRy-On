# from sqlalchemy.orm import Session
# from models import User
# from auth import hash_password, verify_password

# def get_user_by_username(db: Session, username: str):
#     return db.query(User).filter(User.username == username).first()

# def get_user_by_email(db: Session, email: str):
#     return db.query(User).filter(User.email == email).first()

# def create_user(db: Session, username: str, email: str, password: str):
#     user = User(username=username, email=email, password=hash_password(password))
#     db.add(user)
#     db.commit()
#     db.refresh(user)
#     return user

# def authenticate_user(db: Session, username: str, password: str):
#     user = get_user_by_username(db, username)
#     if not user or not verify_password(password, user.password):
#         return None
#     return user
# from sqlalchemy.orm import Session
# from models import User
# from auth import hash_password, verify_password

# # 1. Email ke zariye user dhoondna
# def get_user_by_email(db: Session, email: str):
#     return db.query(User).filter(User.email == email).first()

# # 2. Naya user create karna (Registration ke liye)
# def create_user(db: Session, first_name: str, last_name: str, email: str, phone_number: str, password: str):
#     db_user = User(
#         first_name=first_name,
#         last_name=last_name,
#         email=email,
#         phone_number=phone_number,
#         password=hash_password(password) # Password hamesha hash karke save karein
#     )
#     db.add(db_user)
#     db.commit()
#     db.refresh(db_user)
#     return db_user

# # 3. Authenticate user (Login ke liye)
# def authenticate_user(db: Session, email: str, password: str):
#     # Pehle email se user dhoondein
#     user = get_user_by_email(db, email)
#     if not user:
#         return None
#     # Phir password match karein
#     if not verify_password(password, user.password):
#         return None
#     return user

# ----------------- FINAL CRUD LOGIC -----------------

from sqlalchemy.orm import Session
from Authentication.models import User
from Authentication.auth import hash_password, verify_password
from datetime import datetime, timedelta
import random

# 1. Email se user dhoondna
def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()

# 2. Registration Logic (Updated with is_active default)
def create_user(db: Session, user_data: dict):
    hashed_pwd = hash_password(user_data['password'])
    
    db_user = User(
        first_name=user_data['first_name'],
        last_name=user_data['last_name'],
        phone_number=user_data['phone_number'],
        email=user_data['email'],
        password=hashed_pwd,
        is_active=False  # Naya user pehle inactive hoga jab tak OTP verify na ho
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

# 3. Authentication Logic (UPDATED - is_deleted check add karo)
def authenticate_user(db: Session, email: str, password: str):
    # Yahan 'is_deleted == False' lazmi check karein
    user = db.query(User).filter(User.email == email, User.is_deleted == False).first()
    if not user:
        return None
    if not verify_password(password, user.password):
        return None
    return user

# 4. OTP Verification Logic
def verify_user_otp(db: Session, phone_number: str, otp_code: str):
    user = db.query(User).filter(User.phone_number == phone_number).first()
    
    if not user:
        return None
    
    # OTP expiry check karo
    if user.otp_expires_at and datetime.utcnow() > user.otp_expires_at:
        return None  # OTP expire ho gaya
    
    # OTP match karo
    if user.otp_code == otp_code:
        user.is_active = True
        user.otp_code = None  # Used OTP ko clear karo
        db.commit()
        return user
    return None

# 5. Password Update (For Change/Reset Password)
def update_password(db: Session, user_id: int, new_password: str):
    user = db.query(User).filter(User.id == user_id).first()
    if user:
        user.password = hash_password(new_password)
        db.commit()
        return True
    return False

# 6. Profile Image Update
def update_user_image(db: Session, user_id: int, image_path: str):
    user = db.query(User).filter(User.id == user_id).first()
    if user:
        user.profile_image = image_path
        db.commit()

# 7. Soft Delete User (UPDATED - password verification add karo)
def soft_delete_user(db: Session, user_id: int, password: str):
    """User ko soft delete karo with password verification"""
    user = db.query(User).filter(User.id == user_id, User.is_deleted == False).first()
    
    if not user:
        return False
    
    # Password verify karo
    if not verify_password(password, user.password):
        return False
    
    # Soft delete karo
    user.is_deleted = True
    db.commit()
    return True

# 8. NAYA: OTP Generate karo
# def generate_otp():
#     """Random 6-digit OTP generate karo"""
#     return str(random.randint(100000, 999999))

# # 9. NAYA: Send OTP to User (Database mein save karo)
# def send_otp_to_user(db: Session, phone_number: str):
#     user = db.query(User).filter(User.phone_number == phone_number).first()
#     if not user:
#         return False
    
#     otp = generate_otp()
#     user.otp_code = otp
#     user.otp_expires_at = datetime.utcnow() + timedelta(minutes=10)  # 10 min validity
#     user.last_otp_sent_at = datetime.utcnow()
#     db.commit()
    
#     # Yahan send to SMS service (Twilio, etc.)
#     print(f"OTP for {phone_number}: {otp}")  # Testing ke liye
#     return True

def generate_otp():
    """Testing ke liye hamesha static OTP '123456' generate karo"""
    return "123456"  # Agar aapko strictly 4 digits ka '1234' chahiye toh yahan "1234" kar dein

# 9. NAYA: Send OTP to User (Database mein save karo)
def send_otp_to_user(db: Session, phone_number: str):
    user = db.query(User).filter(User.phone_number == phone_number).first()
    if not user:
        return False
    
    # Ab yeh har phone number par static 123456 hi generate karega
    otp = generate_otp()
    user.otp_code = otp
    user.otp_expires_at = datetime.utcnow() + timedelta(minutes=10)  # 10 min validity
    user.last_otp_sent_at = datetime.utcnow()
    db.commit()
    
    # Testing log
    print(f"Static OTP for {phone_number}: {otp}")  
    return True

# 10. NAYA: Check karo ke resend OTP kar sakta hai ya nahi
def can_resend_otp(db: Session, phone_number: str):
    user = db.query(User).filter(User.phone_number == phone_number).first()
    if not user or not user.last_otp_sent_at:
        return True, 0
    
    time_since_last_otp = datetime.utcnow() - user.last_otp_sent_at
    resend_cooldown = timedelta(seconds=30)  # 30 seconds mein 1 baar resend kar sakte ho
    
    if time_since_last_otp >= resend_cooldown:
        return True, 0
    else:
        seconds_left = int((resend_cooldown - time_since_last_otp).total_seconds())
        return False, seconds_left

# 11. NAYA: Reset Password with OTP (UPDATED - OTP expiry check add karo)
def reset_user_password(db: Session, email: str, new_password: str, otp_code: str):
    user = db.query(User).filter(User.email == email, User.is_deleted == False).first()
    
    if not user:
        return False
    
    # OTP expiry check karo
    if user.otp_expires_at and datetime.utcnow() > user.otp_expires_at:
        return False
    
    # OTP match karo
    if user.otp_code == otp_code:
        user.password = hash_password(new_password)
        user.otp_code = None  # Used OTP ko clear karo
        db.commit()
        return True
    
    return False