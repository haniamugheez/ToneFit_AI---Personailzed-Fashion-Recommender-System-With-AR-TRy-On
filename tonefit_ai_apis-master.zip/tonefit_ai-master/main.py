# from fastapi import FastAPI, Depends, HTTPException
# from sqlalchemy.orm import Session
# from database import get_db, Base, engine
# from schemas import UserRegister, UserLogin, Token
# from crud import get_user_by_username, get_user_by_email, create_user, authenticate_user
# from auth import create_access_token

# # Ensure tables exist
# Base.metadata.create_all(bind=engine)

# app = FastAPI(title="FastAPI MySQL Auth")

# @app.post("/register")
# def register(user: UserRegister, db: Session = Depends(get_db)):
#     if get_user_by_username(db, user.username):
#         raise HTTPException(status_code=400, detail="Username already exists")
#     if get_user_by_email(db, user.email):
#         raise HTTPException(status_code=400, detail="Email already exists")
#     create_user(db, user.username, user.email, user.password)
#     return {"msg": "User registered successfully"}

# @app.post("/login", response_model=Token)
# def login(user: UserLogin, db: Session = Depends(get_db)):
#     db_user = authenticate_user(db, user.username, user.password)
#     if not db_user:
#         raise HTTPException(status_code=401, detail="Invalid username or password")
#     token = create_access_token({"sub": db_user.username})
#     return {"access_token": token, "token_type": "bearer"}

# 

# from fastapi import FastAPI, Depends, HTTPException
# from sqlalchemy.orm import Session
# from database import get_db, Base, engine
# from schemas import UserRegister, UserLogin, Token, UserOut
# from crud import get_user_by_email, create_user, authenticate_user
# from auth import create_access_token

# # Tables create karein
# Base.metadata.create_all(bind=engine)

# app = FastAPI(title="ToneFit API")

# @app.post("/register", response_model=UserOut)
# def register(user: UserRegister, db: Session = Depends(get_db)):
#     # 1. Check karein ke email pehle se toh nahi hai
#     if get_user_by_email(db, user.email):
#         raise HTTPException(status_code=400, detail="Email already registered")
    
#     # 2. User create karein
#     new_user = create_user(
#         db=db, 
#         first_name=user.first_name,
#         last_name=user.last_name,
#         email=user.email,
#         phone_number=user.phone_number,
#         password=user.password
#     )
#     return new_user

# @app.post("/login", response_model=Token)
# def login_user(user: UserLogin, db: Session = Depends(get_db)):
#     # 3. Authenticate user
#     db_user = authenticate_user(db, user.email, user.password)
#     if not db_user:
#         raise HTTPException(status_code=401, detail="Invalid email or password")
    
#     # 4. Token create karein
#     access_token = create_access_token(data={"sub": db_user.email})
    
#     # Return dictionary jo Token schema se match kare
#     return {"access_token": access_token, "token_type": "bearer"}

# from fastapi import FastAPI, Depends, HTTPException
# from sqlalchemy.orm import Session
# from database import get_db, Base, engine
# from schemas import UserRegister, UserLogin, Token, UserOut
# from crud import get_user_by_email, create_user, authenticate_user
# from auth import create_access_token

# Base.metadata.create_all(bind=engine)

# app = FastAPI(title="ToneFit API")

# @app.post("/register", response_model=UserOut)
# def register(user: UserRegister, db: Session = Depends(get_db)):
#     if get_user_by_email(db, user.email):
#         raise HTTPException(status_code=400, detail="Email already registered")
    
#     new_user = create_user(
#         db=db, 
#         user_data={
#             "first_name": user.first_name,
#             "last_name": user.last_name,
#             "email": user.email,
#             "phone_number": user.phone_number,
#             "password": user.password
#         }
#     )
#     return new_user

# @app.post("/login", response_model=Token)
# def login_user(user: UserLogin, db: Session = Depends(get_db)):
#     db_user = authenticate_user(db, user.email, user.password)
#     if not db_user:
#         raise HTTPException(status_code=401, detail="Invalid email or password")
    
#     access_token = create_access_token(data={"sub": db_user.email})
#     return {"access_token": access_token, "token_type": "bearer"}

## -----------------------  FINAL CODE --------------------------------




import os
import shutil
import uuid
from fastapi import FastAPI, Depends, HTTPException, status, File, UploadFile
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

# Project Imports
from Authentication.database import get_db, Base, engine
import Authentication.models as models
import Authentication.schemas as schemas
from Authentication import crud
from Authentication.auth import create_access_token, get_current_user, authenticate_user
from Skintone_analysis_recommendation.skintone import router as skin_router
from Product_Management.product import router as products_router
from Cart_Management.cart import router as cart_router
from Payment_Management.payment import router as payment_router
from Product_Management import brand
from Payment_Management import payment

# --- 1. DATABASE INITIALIZATION ---
models.Base.metadata.create_all(bind=engine)

# --- 2. APP INITIALIZATION ---
app = FastAPI(
    title="ToneFit API",
    description="AI Fashion Recommendation & Profile Management",
    version="1.0.0",
    docs_url="/docs",
    redoc_url=None
)  

# --- 3. STATIC FILES & DIRECTORY SETUP ---
REQUIRED_FOLDERS = ["static/profile_pics", "static/skin_data"]
for folder in REQUIRED_FOLDERS:
    if not os.path.exists(folder):
        os.makedirs(folder)

app.mount("/static", StaticFiles(directory="static"), name="static")

# --- 4. ROUTER REGISTRATION ---
app.include_router(skin_router)
app.include_router(products_router)
app.include_router(cart_router)
app.include_router(payment_router)
app.include_router(brand.router)
app.include_router(payment.router)


# --- 5. AUTHENTICATION & REGISTRATION ENDPOINTS ---

@app.post("/register", response_model=schemas.UserOut, tags=["Authentication"])
def register(user: schemas.UserRegister, db: Session = Depends(get_db)):
    # Email check
    if crud.get_user_by_email(db, user.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Password validation (pehle check karo)
    if len(user.password) < 8:
        raise HTTPException(status_code=400, detail="Password should be at least 8 characters long")
    
    if len(user.password) > 100:
        raise HTTPException(status_code=400, detail="Password is too long. Please choose a shorter password.")
    
    # User create karo
    user_data = user.model_dump() if hasattr(user, 'model_dump') else user.dict()
    user_data.pop("confirm_password")
    new_user = crud.create_user(db, user_data)
    
    # OTP send karo
    crud.send_otp_to_user(db, new_user.phone_number)
    
    return new_user

@app.post("/verify-otp", tags=["Authentication"])
# def verify_otp(payload: schemas.VerifyOTP, db: Session = Depends(get_db)):
#     user = crud.verify_user_otp(db, payload.phone_number, payload.otp_code)
#     if not user:
#         raise HTTPException(status_code=400, detail="Invalid OTP or Phone Number")
#     return {"message": "OTP Verified Successfully. You can now login."}
def verify_otp(payload: schemas.VerifyOTP, db: Session = Depends(get_db)):
    # MASTER BYPASS: Agar input OTP '1234' hai, toh direct success return karo
    if payload.otp_code == "123456":
        return {"message": "OTP Verified Successfully. You can now login."}
        
    # Baqi normal validation agar purana tariqa chalana ho
    user = crud.verify_user_otp(db, payload.phone_number, payload.otp_code)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid OTP or Phone Number")
    return {"message": "OTP Verified Successfully. You can now login."}


@app.post("/login", response_model=schemas.Token, tags=["Authentication"])
def login_user(user: schemas.UserLogin, db: Session = Depends(get_db)):
    db_user = authenticate_user(db, user.email, user.password)
    if not db_user:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    if hasattr(db_user, 'is_deleted') and db_user.is_deleted:
        raise HTTPException(status_code=401, detail="This account has been deleted")

    if not db_user.is_active:
        raise HTTPException(status_code=403, detail="Please verify your OTP first")
    
    access_token = create_access_token(data={"sub": db_user.email})
    return {"access_token": access_token, "token_type": "bearer"}




# --- 6. PROFILE MANAGEMENT ENDPOINTS ---

@app.get("/profile", response_model=schemas.UserOut, tags=["Profile Management"])
def read_profile(current_user: models.User = Depends(get_current_user)):
    return current_user

@app.post("/profile/upload-image", tags=["Profile Management"])
async def upload_profile_image(
    file: UploadFile = File(...), 
    current_user: models.User = Depends(get_current_user), 
    db: Session = Depends(get_db)
):
    extension = file.filename.split(".")[-1]
    file_name = f"{current_user.id}_profile_{uuid.uuid4().hex}.{extension}"
    file_path = os.path.join("static/profile_pics", file_name)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    web_path = f"/static/profile_pics/{file_name}"
    crud.update_user_image(db, current_user.id, web_path)
    return {"message": "Image uploaded successfully", "path": web_path}

@app.post("/forgot-password", tags=["Authentication"])
def forgot_password(payload: schemas.ForgotPassword, db: Session = Depends(get_db)):
    user = crud.get_user_by_email(db, payload.email)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "OTP sent to your email (Use '1234' for testing)"}

@app.post("/reset-password", tags=["Authentication"])
def reset_password(payload: schemas.ResetPassword, db: Session = Depends(get_db)):
    if payload.new_password != payload.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")
    
    success = crud.reset_user_password(db, payload.email, payload.new_password, payload.otp_code)
    if not success:
        raise HTTPException(status_code=400, detail="Invalid OTP or Email")
    return {"message": "Password reset successfully"}


# Existing imports ke baad add karo ye endpoints:

# --- DELETE PROFILE ENDPOINT ---
@app.delete("/profile", tags=["Profile Management"])
def delete_profile(
    payload: schemas.DeleteAccount,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """User apna account delete kar sakta hai (Soft delete)"""
    
    # Password verify karo
    success = crud.soft_delete_user(db, current_user.id, payload.password)
    
    if not success:
        raise HTTPException(status_code=400, detail="Invalid password")
    
    return {"message": "Account successfully deleted"}

# --- RESEND OTP ENDPOINT ---
@app.post("/resend-otp", response_model=schemas.OTPStatus, tags=["Authentication"])
def resend_otp(payload: schemas.ResendOTP, db: Session = Depends(get_db)):
    """User OTP resend kar sakta hai (30 second cooldown)"""
    
    # Check karo ke resend kar sakta hai ya nahi
    can_resend, seconds_left = crud.can_resend_otp(db, payload.phone_number)
    
    if not can_resend:
        return {
            "can_resend": False,
            "seconds_until_resend": seconds_left,
            "message": f"Please wait {seconds_left} seconds before requesting a new OTP"
        }
    
    # Naya OTP send karo
    user = crud.send_otp_to_user(db, payload.phone_number)
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {
        "can_resend": True,
        "seconds_until_resend": 0,
        "message": "OTP sent successfully (Use '1234' for testing)"
    }

# --- CHANGE PASSWORD ENDPOINT (for logged-in users) ---
@app.post("/change-password", tags=["Profile Management"])
def change_password(
    payload: schemas.PasswordReset,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Logged-in user apna password change kar sakta hai"""
    
    success = crud.update_password(db, current_user.id, payload.new_password)
    
    if not success:
        raise HTTPException(status_code=400, detail="Failed to update password")
    
    return {"message": "Password changed successfully"}

# --- 7. RECOMMENDATION ENDPOINT ---
@app.get("/recommendations", tags=["Core Features"])
async def get_dresses(
    category: str, 
    db: Session = Depends(get_db), 
    current_user: models.User = Depends(get_current_user)
):
    latest_analysis = db.query(models.SkinToneAnalysis).filter(
        models.SkinToneAnalysis.user_id == current_user.id
    ).order_by(models.SkinToneAnalysis.created_at.desc()).first()
    
    if not latest_analysis:
        raise HTTPException(status_code=400, detail="Pehle skin tone analysis karein (Camera screen)")

    tone = latest_analysis.detected_tone
    
    return {
        "user": f"{current_user.first_name} {current_user.last_name}",
        "detected_tone": tone,
        "selected_category": category,
        "recommendations": [] 
    }

# --- 8. BASE ENDPOINT ---
@app.get("/", tags=["General"])
def home():
    return {"message": "Welcome to ToneFit AI API", "status": "Active"}