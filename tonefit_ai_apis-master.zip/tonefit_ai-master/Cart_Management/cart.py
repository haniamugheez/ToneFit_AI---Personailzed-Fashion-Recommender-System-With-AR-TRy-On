from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from Authentication.database import get_db
from Authentication.auth import get_current_user
from Authentication import models
from pydantic import BaseModel

router = APIRouter(prefix="/cart", tags=["Cart Management"])

class CartItemCreate(BaseModel):
    product_id: int
    size: str  # Kept for AR virtual try-on adjustment on frontend
    quantity: int

@router.post("/add")
async def add_to_cart(item: CartItemCreate, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # 1. 🔥 Product exists check (Variant check removed!)
    # Hum bas yeh check karenge ke jo product user add kar raha hai, kya woh products table mein maujood hai ya nahi.
    product = db.query(models.Product).filter(models.Product.id == item.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found in our catalog.")

    # 2. Check if the user has already added this specific product with the same size to the cart
    existing_item = db.query(models.Cart).filter(
        models.Cart.user_id == current_user.id,
        models.Cart.product_id == item.product_id,
        models.Cart.size == item.size
    ).first()

    if existing_item:
        # If already in cart, simply increment the quantity
        existing_item.quantity += item.quantity
    else:
        # Add a new line item to the cart table with the user's selected size
        new_cart_item = models.Cart(
            user_id=current_user.id,
            product_id=item.product_id,
            size=item.size,  # Passed to track sizing requirements for AR rendering
            quantity=item.quantity
        )
        db.add(new_cart_item)
        
    db.commit()
    return {"status": "Success", "message": "Item added to cart successfully!"}