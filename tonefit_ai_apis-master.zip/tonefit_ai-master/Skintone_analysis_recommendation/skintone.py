import os
import cv2
import numpy as np
import uuid
from fastapi import APIRouter, File, UploadFile, Depends, HTTPException
from sqlalchemy.orm import Session

# Imports from your Auth system
from Authentication.database import get_db
from Authentication.models import SkinToneAnalysis
from Authentication.auth import get_current_user
import Authentication.models as models

router = APIRouter(prefix="/skintone", tags=["Skintone Analysis"])

# --- Skin Tone Detection Logic ---
def detect_skin_tone_logic(image_path):
    img = cv2.imread(image_path)
    if img is None:
        return None, None
    
    h, w, _ = img.shape
    roi = img[h//3:2*h//3, w//3:2*w//3] # Center area focus
    avg_color = np.average(np.average(roi, axis=0), axis=0) # BGR format
    
    # BGR to HEX
    hex_val = '#%02x%02x%02x' % (int(avg_color[2]), int(avg_color[1]), int(avg_color[0]))
    
    # Categorization based on brightness
    brightness = sum(avg_color) / 3
    if brightness > 180:
        tone_name = "Fair"
    elif brightness > 120:
        tone_name = "Medium"
    else:
        tone_name = "Deep"
        
    return tone_name, hex_val

# --- Endpoint: Camera Picture Upload & Analysis ---
@router.post("/analyze")
async def analyze_skin(
    file: UploadFile = File(...), 
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    # 1. Save Image
    path_dir = "static/skin_data"
    if not os.path.exists(path_dir):
        os.makedirs(path_dir)
        
    file_name = f"user_{current_user.id}_{uuid.uuid4().hex}.jpg"
    file_path = os.path.join(path_dir, file_name)
    
    with open(file_path, "wb") as buffer:
        buffer.write(await file.read())

    # 2. Process Image
    tone, hex_code = detect_skin_tone_logic(file_path)
    
    if not tone:
        raise HTTPException(status_code=400, detail="Could not process image")

    # 3. Save to Database
    new_analysis = SkinToneAnalysis(
        user_id=current_user.id,
        detected_tone=tone,
        hex_code=hex_code,
        skin_image_path=file_path
    )
    db.add(new_analysis)
    db.commit()
    db.refresh(new_analysis)

    return {
        "status": "Success",
        "user": current_user.first_name,
        "detected_tone": tone,
        "hex": hex_code,
        "message": "Now proceed to category selection"
    }

@router.get("/recommendations")
async def get_clothing_recommendations(
    category: str,  # Wedding, Casual, Party (Main Category)
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    # 1. Database se user ka LATEST skin tone fetch karein
    latest_analysis = db.query(models.SkinToneAnalysis).filter(
        models.SkinToneAnalysis.user_id == current_user.id
    ).order_by(models.SkinToneAnalysis.created_at.desc()).first()

    if not latest_analysis:
        raise HTTPException(
            status_code=404, 
            detail="Pehle camera screen se skin tone analyze karein."
        )

    tone = latest_analysis.detected_tone

    # 2. Detailed Color Guidance
    color_guidance = {
        "Fair": {
            "hex_palette": ["#50C878", "#002366", "#E0115F", "#FFD1DC", "#3EB489"],
            "names": ["Emerald Green", "Royal Blue", "Ruby Red", "Pastel Pink"],
            "advice": "Cool aur deep jewel tones aap par bohat suit karti hain."
        },
        "Medium": {
            "hex_palette": ["#FFDB58", "#008080", "#800000", "#BAB86C", "#F5F5DC"],
            "names": ["Mustard", "Teal", "Maroon", "Olive Green", "Beige"],
            "advice": "Earthy aur warm tones aapki skin ko natural glow deti hain."
        },
        "Deep": {
            "hex_palette": ["#FF8C00", "#FFFFFF", "#FF00FF", "#7851A9", "#FFF44F"],
            "names": ["Bright Orange", "White", "Royal Purple", "Lemon Yellow"],
            "advice": "Vibrant aur high-contrast colors aap par bohat attractive lagte hain."
        }
    }

    selected_guidance = color_guidance.get(tone, {"hex_palette": [], "names": [], "advice": ""})

    # 3. Real Database Products Fetch Karein (Updated to match your clean CSV columns structure)
    # Hum match karenge main category (Wedding, Casual, Party) ko jo user select karega
    products = db.query(models.Product).filter(
        models.Product.category == category
    ).all()

    # 4. Final Response
    return {
        "user_profile": {
            "name": current_user.first_name,
            "detected_tone": tone,
            "detected_hex": latest_analysis.hex_code
        },
        "style_guide": {
            "suggested_colors": selected_guidance["names"],
            "hex_codes": selected_guidance["hex_palette"],
            "expert_advice": selected_guidance["advice"]
        },
        "recommended_outfits": products  # CSV data list with price, sub_category, and brand_name!
    }