from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from Authentication.database import get_db
from Authentication import models, schemas
from Authentication.auth import get_current_user 

router = APIRouter(prefix="/brands", tags=["Brand Management"])

# 1. GET ALL BRANDS
@router.get("/", response_model=List[schemas.BrandResponse])
async def get_all_brands(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    brands = db.query(models.Brand).all()
    fav_brand_ids = db.query(models.FavoriteBrand.brand_id).filter(models.FavoriteBrand.user_id == current_user.id).all()
    fav_brand_ids = [f[0] for f in fav_brand_ids]

    result = []
    for brand in brands:
        brand_data = schemas.BrandResponse.from_attributes(brand)
        brand_data.is_favorite = brand.id in fav_brand_ids
        result.append(brand_data)
    return result

# 2. GET PRODUCTS BY BRAND (Option 1: Filter from your main product table)
@router.get("/{brand_id}/products")
async def get_products_by_brand(brand_id: int, db: Session = Depends(get_db)):
    brand = db.query(models.Brand).filter(models.Brand.id == brand_id).first()
    if not brand:
        raise HTTPException(status_code=404, detail="Brand not found")
    return db.query(models.Product).filter(models.Product.brand_name == brand.name).all()

# 3. TOGGLE FAVORITE BRAND
@router.post("/{brand_id}/toggle-favorite")
async def toggle_favorite(brand_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    brand = db.query(models.Brand).filter(models.Brand.id == brand_id).first()
    if not brand:
        raise HTTPException(status_code=404, detail="Brand not found")

    existing_fav = db.query(models.FavoriteBrand).filter(
        models.FavoriteBrand.user_id == current_user.id, models.FavoriteBrand.brand_id == brand_id
    ).first()

    if existing_fav:
        db.delete(existing_fav)
        db.commit()
        return {"message": "Removed from favorites", "is_favorite": False}
    else:
        new_fav = models.FavoriteBrand(user_id=current_user.id, brand_id=brand_id)
        db.add(new_fav)
        db.commit()
        return {"message": "Added to favorites", "is_favorite": True}

# 4. GET FAVORITE BRANDS LIST
@router.get("/favorites", response_model=List[schemas.BrandResponse])
async def get_favorite_brands(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    fav_entries = db.query(models.FavoriteBrand).filter(models.FavoriteBrand.user_id == current_user.id).all()
    result = []
    for entry in fav_entries:
        brand_data = schemas.BrandResponse.from_attributes(entry.brand)
        brand_data.is_favorite = True
        result.append(brand_data)
    return result