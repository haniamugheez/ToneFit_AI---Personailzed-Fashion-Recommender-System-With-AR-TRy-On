import re

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from Authentication.database import get_db
from Authentication import models
import csv


router = APIRouter(prefix="/products", tags=["Product Inventory"])

@router.get("/{product_id}/sizes")
async def get_product_sizes(product_id: int, db: Session = Depends(get_db)):
    # 1. Pehle check karenge ke kya yeh product catalog mein exist karta bhi hai ya nahi
    product = db.query(models.Product).filter(models.Product.id == product_id).first()
    
    if not product:
        raise HTTPException(status_code=404, detail="Product not found in our catalog.")
        
    # 2. Kyunki ProductVariant table khatam ho gaya hai, hum direct standard sizes return karenge
    # Yeh sizes Flutter app receive karega aur AR Try-On module ko pass karega scale adjustment ke liye.
    return {
        "product_id": product_id,
        "product_name": product.name,
        "base_price": product.price,
        "available_sizes": ["S", "M", "L", "XL"]  # Standard sizes for AR Try-on dynamic simulation
    }

